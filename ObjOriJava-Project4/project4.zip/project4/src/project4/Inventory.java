/**
 * 
 */
package project4;

/**
 * @author tammyhuynh
 *	this class stores inventory information regarding the number of items, quantity, and costs.
 */
import java.util.Scanner;

public class Inventory {
	
	private int itemNumber; 		//An int that holds the item’s number.
	private  int quantity; 			//An int that holds the quantity of the item on hand.
	private double cost; 			//A double that holds the wholesale per-unit cost of the item
	
	
	Inventory(){					//default constructor- Sets all the member variables to 0
		itemNumber = 0;
		quantity = 0;
		cost = 0;
		System.out.println("Demonstrating the Default Constructor");
		System.out.printf(" Item Number :  %s %n Quantity    :  %s %n Cost        : $%.2f %n Total Cost  : $%.2f %n%n", itemNumber, quantity, cost, getTotalCost(quantity,cost));
		
	}
									
	Inventory(Scanner input){		//second constructor - Accepts an item’s number, quantity, and cost as arguments
		
		
		System.out.print("Please Enter the Item Number: ");
		setItemNumber(input.nextInt(), input);
		
		System.out.print("Please Enter the Quantity: ");
		setQuantity(input.nextInt(), input);
		
		System.out.print("Please Enter the Cost: ");
		setCost(input.nextDouble(), input);
		
		System.out.println("\nDemonstrating the User Validation Function");
		System.out.printf(" Item Number :  %s %n Quantity    :  %s %n Cost        : $%.2f %n Total Cost  : $%.2f %n%n", getItemNumber(), getQuantity(), getCost(), getTotalCost(getQuantity(),getCost()));
	}
	
	public void setItemNumber(int inputItemNumber, Scanner input) {	//Copies and Pastes approved int Argument.
		boolean checking = ValidInt(inputItemNumber);
		while (checking == false) {
			System.out.println("The Item Number must be greater than or equal to 0. Please try again:");
			inputItemNumber = input.nextInt();
			checking = ValidInt(inputItemNumber);
		}
		this.itemNumber = inputItemNumber;
	}
	public void setQuantity(int inputQuantity, Scanner input) {		//Copies and pastes approved int Argument
		boolean checking = ValidInt(inputQuantity);
		while (checking == false) {
			System.out.println("The Quantity must be greater than or equal to 0. Please try again:");
			inputQuantity = input.nextInt();
			checking = ValidInt(inputQuantity);
		}
		this.quantity = inputQuantity;
	}
	public void setCost(double inputCost, Scanner input) {			//Copies and pastes approved double argument
		boolean checking = ValidFloat(inputCost);
		while (checking == false) {
			System.out.println("The Cost must be greater than or equal to 0. Please try again:");
			inputCost = input.nextInt();
			checking = ValidFloat(inputCost);
		}
		
		this.cost = inputCost;
		
	}
	public int getItemNumber () {									//Returns Private Variable
		return this.itemNumber;
	}
	public int getQuantity () {										//Returns Private Variable
		return this.quantity;
	}
	public double getCost () {										//Returns Private Variable
		return this.cost;
	}
	public double getTotalCost(int quantity, double cost) {			//Returns Private Variable (also calculates total cost)
		return cost*quantity;
		
	}
	
	public Boolean ValidInt(int inputNum) {							//Validates user input for positive or 0 inputs
		Boolean validation;
		if (inputNum< 0) {
			validation = false;
		} else {
			validation = true;
		}
		return validation;
	}
	public Boolean ValidFloat(double inputMoney) {					//validates user input for positive or 0 inputs
		Boolean validation;
		if (inputMoney< 0) {
			validation = false;
		} else {
			validation = true;
		}
		return validation;
	}
}
