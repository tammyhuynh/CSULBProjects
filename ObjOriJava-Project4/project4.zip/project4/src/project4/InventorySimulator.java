/**
 * 
 */
package project4;

/**
 * @author tammyhuynh
 *
 */
import java.util.Scanner;


public class InventorySimulator {
	
	public static void main (String[] args) {
		Inventory storage = new Inventory();			//Uses Default Constructor
		Scanner scan = new Scanner(System.in);			//Creates scanner for user inputs
		
		Inventory input = new Inventory(scan);			//Uses Second Constructor for user input
		scan.close();									//closes scanner
	}
}
